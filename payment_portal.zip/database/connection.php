<?php


$conn = new mysqli('localhost','root','','payment_portal');

if(!$conn)
{
  die("connection failed".$conn->connect_error);
}
