/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 100424
 Source Host           : localhost:3306
 Source Schema         : payment_portal

 Target Server Type    : MySQL
 Target Server Version : 100424
 File Encoding         : 65001

 Date: 09/12/2022 05:58:57
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for donation
-- ----------------------------
DROP TABLE IF EXISTS `donation`;
CREATE TABLE `donation`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `amount` decimal(11, 2) NULL DEFAULT NULL,
  `donate_date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of donation
-- ----------------------------
INSERT INTO `donation` VALUES (7, 'donor@gmail.com', 'George clooney', 5555.00, '2022-12-09');
INSERT INTO `donation` VALUES (8, 'razakmahama.rm@gmail.com', 'Boateng Ebenezer', 10000.00, '2022-12-09');
INSERT INTO `donation` VALUES (9, 'razak@gmail.com', 'Abdul-Razak Mahama', 5454.00, '2022-12-09');
INSERT INTO `donation` VALUES (10, 'razak@gmail.com', 'George clooney', 10000.00, '2022-12-09');
INSERT INTO `donation` VALUES (11, 'razak@gmail.com', 'Abdul-Razak Mahama', 5454.00, '2022-12-09');
INSERT INTO `donation` VALUES (12, 'razak@gmail.com', 'Abdul-Razak Mahama', 5454.00, '2022-12-09');
INSERT INTO `donation` VALUES (13, 'razak@gmail.com', 'Abdul-Razak Mahama', 5555.00, '2022-12-09');

-- ----------------------------
-- Table structure for fees
-- ----------------------------
DROP TABLE IF EXISTS `fees`;
CREATE TABLE `fees`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `accrued_date` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `status` tinyint(1) NULL DEFAULT NULL,
  `fullname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `studentID` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of fees
-- ----------------------------
INSERT INTO `fees` VALUES (1, '500', '2022-12-06', 1, 'john boateng', 'student@gmail.com', 'SD123');
INSERT INTO `fees` VALUES (2, '500', '2022-12-06', 1, 'john boateng', 'student@gmail.com', 'SD123');
INSERT INTO `fees` VALUES (3, '500', '2022-12-06', 0, 'john boateng', 'student@gmail.com', 'SD123');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `studentID` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, 'SD123', '123');
INSERT INTO `student` VALUES (2, 'SD122', '123');
INSERT INTO `student` VALUES (3, 'SD121', '123');

SET FOREIGN_KEY_CHECKS = 1;
