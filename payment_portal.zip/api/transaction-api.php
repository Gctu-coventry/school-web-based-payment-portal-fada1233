<?php
$user = array("user" => "admin", "password" => 123);
$_SERVER['PHP_AUTH_USER'] = $user['user'];
$_SERVER['PHP_AUTH_PW'] = $user['password'];
include "../database/connection.php";
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="My Realm"');
    header('HTTP/1.0 401 Unauthorized');
    //echo 'Text to send if user hits Cancel button';
    exit;
} else {
    $encoded = file_get_contents('php://input');
    $decoded = json_decode($encoded, true);
    if (isset($decoded)) {
        if ($_SERVER['PHP_AUTH_USER'] == $decoded['username'] && $_SERVER['PHP_AUTH_PW'] == $decoded['password']) 
        {
        $d_student_id = $decoded['student_id'];
        $sql = "SELECT * FROM fees where studentID = '$d_student_id' AND status=1";
        $sql_query = mysqli_query($conn, $sql);
        if ($sql_query && mysqli_num_rows($sql_query) > 0) 
        {
            while ($row = mysqli_fetch_assoc($sql_query)) {
                $date  = $row['accrued_date'];
                $amount = $row['amount'];
                $id = $row['id'];
                $status = 1;
                $response[] = array(
                    "id" => $id,
                    "date" => $date,
                    "amount" => $amount,
                    "status" => $status
                );
            }
        } else {
            $response[] = array(
                "id" => $id,
                "date" => '',
                "amount" => '',
                "status" => 0
            );
        }
        echo json_encode($response);
    }
}
    }
