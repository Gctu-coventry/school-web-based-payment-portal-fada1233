<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">

    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <title>Login Student</title>
</head>

<div>
    <div></div>
</div>

<body>

    <div class="homepage_container">
        <form class="login_form" action="database/student_login.php" method="post">
            <h2>Login</h2>
            <?php
            if (isset($_SESSION['error'])) {
                echo "<h4 style='text-align:center;color:red'>*Wrong login Credentials*</h4>";
                unset($_SESSION['error']);
            }
            ?>
            <h4>Student ID</h4>
            <input required type="text" name="studentID">
            <br>
            <h4>Password</h4>
            <input required type="password" name="password">
            <input type="submit" name="submit" value="Login">
        </form>
    </div>

</body>

</html>