<?php
session_start();
if (!isset($_SESSION['student_id'])) {
    header('location:login.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">

    <link href="assets/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/css/all.min.css" rel="stylesheet">
    <title>Accrued Fees</title>
</head>

<body>

    <div class="table_wrapper">

        <div class="table_container">
            <div class="header">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="accrued.php"><i class="fas  fa-money-bill-wave"></i> Make Payment</a>
                <a href="donate.php"><i class="fas fa-donate"></i> Donate</a>
                <a href="transaction_history.php"><i class="fas fa-history"></i> Transaction History</a>
                <a href="refund.php"><i class="fas  fa-undo-alt"></i> Refund Sale</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i>  Logout</a>
            </div>

            <h2>Owed or Accrued Amount</h2>
            <table>
                <thead>
                    <th>#</th>
                    <th>date</th>
                    <th>Amount</th>
                    <th>Action</th>
                </thead>
                <tbody>
                    <?php
                    $student_id = $_SESSION['student_id'];
                    function callAPI($method, $url, $data)
                    {
                        $curl = curl_init();
                        switch ($method) {
                            case "POST":
                                curl_setopt($curl, CURLOPT_POST, 1);
                                if ($data)
                                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                                break;
                            case "PUT":
                                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                                if ($data)
                                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                                break;
                            default:
                                if ($data)
                                    $url = sprintf("%s?%s", $url, http_build_query($data));
                        }
                        // OPTIONS:
                        curl_setopt($curl, CURLOPT_URL, $url);
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                            'APIKEY: 111111111111111111111',
                            'Content-Type: application/json',
                        ));
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                        // EXECUTE:
                        $result = curl_exec($curl);
                        if (!$result) {
                            die("Connection Failure");
                        }
                        curl_close($curl);
                        return $result;
                    }


                    $data_array =  array(
                        "username"        => "admin",
                        "password"         => "123",
                        "student_id" => "SD123"
                    );
                    $make_call = callAPI('POST', 'http://localhost/payment_portal/api/debt-api.php/', json_encode($data_array));
                    $response = json_decode($make_call, true);
                    //print_r($response[0]['date']);
                    if (isset($response)) {
                        $a = 1;
                        for ($i = 0; $i < count($response); $i++) {
                            echo "
                  <tr> 
                      <td>" . $a++ . "</td>
                      <td>" . $response[$i]['date'] . "</td>
                      <td>" . $response[$i]['amount'] . "</td>
                      <td><a href='payment.php?id=" . $response[$i]['id'] . "&amount=" . $response[$i]['amount'] . "'>Make Payment</a></td>
                </tr>";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>